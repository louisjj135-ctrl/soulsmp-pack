# SoulSMP: Crimson Relic armour icons (32x32), matching the Crimson Mace and Bloodriver Katana.
# Palette: obsidian black-violet plates, crimson veins/gems, gold trim and spikes.
import sys, os
from PIL import Image, ImageDraw
OUT = sys.argv[1]
W = 32
T = (0,0,0,0)
OB = [(10,7,16),(24,17,34),(42,30,56),(66,50,86)]          # outline, dark, mid, light plate
CR = [(70,6,14),(150,12,26),(235,36,52),(255,140,140)]      # deep, crimson, bright, hot
GD = [(110,78,14),(196,146,28),(246,204,70),(255,240,160)]  # shadow, gold, light, shine

def new(): return Image.new("RGBA",(W,W),T)
def poly(im, pts, c): ImageDraw.Draw(im).polygon(pts, fill=c)
def rect(im, x0,y0,x1,y1,c): ImageDraw.Draw(im).rectangle([x0,y0,x1,y1], fill=c)
def px(im,x,y,c):
    if 0<=x<W and 0<=y<W: im.putpixel((x,y),c)
def line(im, pts, c): ImageDraw.Draw(im).line(pts, fill=c, width=1)

def silhouette(draw_fn):
    m = Image.new("L",(W,W),0)
    draw_fn(ImageDraw.Draw(m))
    return m

def shade(sil):
    """plate shading from a silhouette mask: outline, light top-left, dark bottom-right"""
    im = new()
    p = sil.load()
    def on(x,y): return 0<=x<W and 0<=y<W and p[x,y]>0
    for y in range(W):
        for x in range(W):
            if not on(x,y): continue
            edge = not (on(x-1,y) and on(x+1,y) and on(x,y-1) and on(x,y+1))
            if edge:
                im.putpixel((x,y),OB[0]+(255,)); continue
            tl = not (on(x-1,y) and on(x,y-1)) or not (on(x-2,y) and on(x,y-2))
            br = not (on(x+1,y) and on(x,y+1)) or not (on(x+2,y) and on(x,y+2))
            c = OB[2]
            if tl: c = OB[3]
            elif br: c = OB[1]
            im.putpixel((x,y),c+(255,))
    return im

def spike(im, x, y, dx, dy, length, base=1):
    """gold triangle spike: base centred on (x,y), pointing along (dx,dy)"""
    half = base + 1
    tip = (x + dx*length, y + dy*length)
    if dx == 0:
        pts = [(x-half, y), (x+half, y), tip]
    else:
        pts = [(x, y-half), (x, y+half), tip]
    d = ImageDraw.Draw(im)
    d.polygon(pts, fill=GD[1]+(255,))
    d.line([pts[0], tip], fill=GD[2]+(255,))
    px(im, tip[0], tip[1], GD[3]+(255,))

def gem(im, cx, cy, r=2):
    for dy in range(-r-1, r+2):
        for dx in range(-r-1, r+2):
            d = dx*dx+dy*dy
            if d <= r*r: px(im,cx+dx,cy+dy,CR[2])
            elif d <= (r+1)*(r+1): px(im,cx+dx,cy+dy,GD[1])
    px(im,cx,cy,CR[3]); px(im,cx-1,cy-1,CR[3])
    px(im,cx+1,cy+1,CR[1])

def vein(im, pts):
    line(im, pts, CR[1])
    for (x,y) in pts[::2]: px(im,x,y,CR[2])

def helmet():
    sil = silhouette(lambda d: d.polygon([(6,28),(6,14),(9,8),(16,5),(23,8),(26,14),(26,28),(21,28),(21,23),(11,23),(11,28)], fill=255))
    im = shade(sil)
    # brow band + cheek trim
    line(im, [(8,12),(24,12)], GD[1]); line(im, [(8,11),(24,11)], GD[2])
    line(im, [(7,15),(7,27)], GD[1]); line(im, [(25,15),(25,27)], GD[1])
    # visor slit with glowing eyes
    rect(im, 10,15,22,19, OB[0]+(255,))
    rect(im, 11,16,14,18, CR[1]+(255,)); rect(im, 18,16,21,18, CR[1]+(255,))
    rect(im, 12,17,13,17, CR[3]+(255,)); rect(im, 19,17,20,17, CR[3]+(255,))
    rect(im, 15,15,17,22, OB[0]+(255,))
    # crest spikes (mace spikes in gold)
    spike(im,16,6,0,-1,5,1); spike(im,10,9,0,-1,4,0); spike(im,22,9,0,-1,4,0)
    # veins
    vein(im, [(9,13),(9,14),(8,15)]); vein(im, [(23,13),(23,14),(24,15)])
    vein(im, [(13,24),(13,27)]); vein(im, [(19,24),(19,27)])
    return im

def chestplate():
    def f(d):
        d.polygon([(3,10),(8,6),(12,6),(16,9),(20,6),(24,6),(29,10),(29,17),(25,17),(25,28),(7,28),(7,17),(3,17)], fill=255)
    sil = silhouette(f); im = shade(sil)
    # collar cut-out
    poly(im,[(12,6),(16,10),(20,6),(19,6),(16,8),(13,6)], OB[0]+(255,))
    # gold bands
    line(im,[(8,22),(24,22)],GD[1]); line(im,[(8,21),(24,21)],GD[2])
    line(im,[(8,27),(24,27)],GD[1])
    line(im,[(4,16),(8,16)],GD[1]); line(im,[(24,16),(28,16)],GD[1])
    # veins radiating from the core
    vein(im,[(14,15),(12,14),(11,12),(9,11)]); vein(im,[(18,15),(20,14),(21,12),(23,11)])
    vein(im,[(14,19),(11,20),(9,19)]); vein(im,[(18,19),(21,20),(23,19)])
    vein(im,[(16,20),(16,24),(15,26)])
    # core gem in gold ring
    gem(im,16,16,2)
    # shoulder spikes
    spike(im,5,10,0,-1,5,1); spike(im,27,10,0,-1,5,1)
    spike(im,10,6,0,-1,3,0); spike(im,22,6,0,-1,3,0)
    return im

def leggings():
    def f(d):
        d.polygon([(6,5),(26,5),(26,12),(25,28),(18,28),(16,15),(14,28),(7,28),(6,12)], fill=255)
    sil = silhouette(f); im = shade(sil)
    # belt
    rect(im,7,6,25,9, GD[1]+(255,)); line(im,[(7,6),(25,6)],GD[2]); line(im,[(7,9),(25,9)],GD[0])
    for x in (9,13,19,23): px(im,x,7,OB[0]+(255,)); px(im,x,8,OB[0]+(255,))
    gem(im,16,8,1)
    # veins down each leg
    vein(im,[(10,11),(10,14),(11,17),(10,21),(9,25)]); vein(im,[(22,11),(22,14),(21,17),(22,21),(23,25)])
    # knee guards
    for cx in (11,21):
        rect(im,cx-2,18,cx+2,20,GD[1]+(255,)); px(im,cx,17,GD[3]); px(im,cx,16,GD[2])
        line(im,[(cx-2,18),(cx+2,18)],GD[2])
    line(im,[(7,26),(13,26)],GD[1]); line(im,[(19,26),(25,26)],GD[1])
    return im

def boots():
    def f(d):
        d.polygon([(5,6),(13,6),(13,21),(15,23),(15,28),(3,28),(3,23),(5,21)], fill=255)
        d.polygon([(19,6),(27,6),(27,21),(29,23),(29,28),(17,28),(17,23),(19,21)], fill=255)
    sil = silhouette(f); im = shade(sil)
    for ox in (0,14):
        rect(im,4+ox,6,13+ox,9,GD[1]+(255,)); line(im,[(4+ox,6),(13+ox,6)],GD[2]); gem(im,8+ox,8,0)
        vein(im,[(8+ox,11),(8+ox,14),(9+ox,17),(10+ox,20),(11+ox,23)])
        # gold toe cap + red toe gem
        rect(im,4+ox,25,14+ox,27,GD[1]+(255,)); line(im,[(4+ox,25),(14+ox,25)],GD[2])
        px(im,6+ox,26,CR[2]); px(im,7+ox,26,CR[3])
        spike(im,3+ox,26,-1,0,3,0)
    return im

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for name, fn in (("relic_helmet",helmet),("relic_chestplate",chestplate),("relic_leggings",leggings),("relic_boots",boots)):
        fn().save(os.path.join(OUT, name+".png"))
    print("ok")
