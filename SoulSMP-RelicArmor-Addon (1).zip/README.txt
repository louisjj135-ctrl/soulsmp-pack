SoulSMP Crimson Relic armour icons (add-on for the resource pack)

Merge into your CURRENT resource pack (v8) by copying the assets folder over it:
  assets/minecraft/items/netherite_helmet|chestplate|leggings|boots.json   (new: custom model data 1 -> relic model)
  assets/soulsmp/models/item/relic_helmet|chestplate|leggings|boots.json
  assets/soulsmp/textures/item/relic_helmet|chestplate|leggings|boots.png  (new art, replaces the old icons)
Do NOT overwrite netherite_sword.json / mace.json (the katana and mace already work in v8).
Only items with custom model data 1 change (the Soul Relic pieces); ordinary netherite armour keeps its vanilla look.
Players must re-download the pack. The art shows in the inventory, shop, hand and on the ground.
The armour worn on the body still uses the vanilla netherite look.
